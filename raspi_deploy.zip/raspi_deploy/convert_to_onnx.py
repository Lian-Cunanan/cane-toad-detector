#!/usr/bin/env python3
# =============================================================================
# YOLO PT to ONNX Converter
# =============================================================================
#
# Converts YOLOv8 PyTorch model (.pt) to ONNX format (.onnx)
# Run this ONCE on Raspberry Pi after transferring best.pt
#
# USAGE:
#   1. Install ultralytics (temporarily):
#        pip3 install ultralytics
#
#   2. Run converter:
#        python3 convert_to_onnx.py
#
#   3. Uninstall ultralytics (optional, to save space):
#        pip3 uninstall ultralytics torch torchvision -y
#
# =============================================================================

import sys
from pathlib import Path

try:
    from ultralytics import YOLO
except ImportError:
    print("[ERROR] ultralytics not found!")
    print("[INFO] Install it with: pip3 install ultralytics")
    sys.exit(1)


def convert_to_onnx(pt_path="best.pt", onnx_path="best.onnx"):
    """Convert PyTorch model to ONNX format."""
    
    pt_file = Path(pt_path)
    if not pt_file.exists():
        print(f"[ERROR] Model file not found: {pt_path}")
        print(f"[INFO] Make sure {pt_path} is in the current directory")
        sys.exit(1)
    
    print("="*70)
    print("YOLO PyTorch → ONNX Converter")
    print("="*70)
    print(f"\n[INFO] Loading model: {pt_path}")
    
    try:
        # Load YOLO model
        model = YOLO(pt_path)
        
        print(f"[INFO] Converting to ONNX format...")
        print("[INFO] This may take a few minutes...\n")
        
        # Export to ONNX
        model.export(
            format='onnx',
            imgsz=640,
            simplify=True,
            opset=12
        )
        
        # Check if conversion was successful
        onnx_file = Path(onnx_path)
        if not onnx_file.exists():
            # Sometimes ultralytics saves with different name
            default_name = pt_file.stem + ".onnx"
            if Path(default_name).exists() and default_name != onnx_path:
                Path(default_name).rename(onnx_path)
        
        if Path(onnx_path).exists():
            file_size = Path(onnx_path).stat().st_size / (1024 * 1024)
            print(f"\n✅ Conversion successful!")
            print(f"[INFO] ONNX model saved: {onnx_path} ({file_size:.2f} MB)")
            print(f"\n[INFO] You can now run: python3 detector_raspi.py")
            print(f"[INFO] To save space, uninstall ultralytics: pip3 uninstall ultralytics torch torchvision -y")
        else:
            print(f"\n❌ Conversion failed - ONNX file not found")
            sys.exit(1)
    
    except Exception as e:
        print(f"\n❌ Conversion failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    # Check for command line arguments
    if len(sys.argv) > 1:
        pt_path = sys.argv[1]
        onnx_path = sys.argv[2] if len(sys.argv) > 2 else "best.onnx"
    else:
        pt_path = "best.pt"
        onnx_path = "best.onnx"
    
    convert_to_onnx(pt_path, onnx_path)
