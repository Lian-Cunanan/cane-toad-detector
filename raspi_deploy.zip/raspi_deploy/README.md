# Cane Toad Detector - Raspberry Pi Deployment

Lightweight ONNX-based cane toad detector optimized for Raspberry Pi.

## 📦 Package Contents

- `convert_to_onnx.py` - PyTorch to ONNX converter (run once)
- `detector_raspi.py` - Main detector script
- `best.pt` - YOLOv8 PyTorch model (will be converted)
- `class_names.json` - Object class labels
- `requirements.txt` - Python dependencies

## 🚀 Quick Start

### 1. Convert Model (Run Once)

First, convert the PyTorch model to ONNX:

```bash
# Install ultralytics (temporarily)
pip3 install ultralytics

# Convert model
python3 convert_to_onnx.py

# Optional: Uninstall ultralytics to save space
pip3 uninstall ultralytics torch torchvision -y
```

### 2. Install Runtime Dependencies

```bash
pip3 install -r requirements.txt
```

### 3. Run Detector

**With display:**
```bash
python3 detector_raspi.py
```

**Headless mode (no display):**
```bash
python3 detector_raspi.py --headless
```

### 3. Options

```bash
python detector_raspi.py --help
```

Common options:
- `--camera 0` - Camera device index (default: 0)
- `--conf 0.5` - Confidence threshold (default: 0.5)
- `--skip 2` - Process every N frames (default: 2)
- `--headless` - Run without display window

## 📷 Camera Setup

Make sure your camera is connected and enabled:

```bash
# List video devices
ls /dev/video*

# Test camera
raspistill -o test.jpg
```

For Raspberry Pi Camera Module, enable it in `raspi-config`:
```bash
sudo raspi-config
# → Interface Options → Camera → Enable
```

## 🎯 Example Commands

**High accuracy (slower):**
```bash
python detector_raspi.py --conf 0.7 --skip 1
```

**Fast performance (lower accuracy):**
```bash
python detector_raspi.py --conf 0.4 --skip 3
```

**Headless logging:**
```bash
python detector_raspi.py --headless --conf 0.5 > detections.log 2>&1
```

## 📊 Performance Tips

- Use `--skip 2` or higher for better FPS on Raspberry Pi 4
- Lower `--conf` threshold to catch more detections
- Use `--headless` mode for ~20% performance boost
- Ensure adequate cooling for sustained performance

## 🐛 Troubleshooting

**Camera not found:**
```bash
# Check camera connection
vcgencmd get_camera

# Try different camera index
python detector_raspi.py --camera 1
```

**Low FPS:**
- Increase `--skip` value
- Use `--headless` mode
- Reduce resolution: `--width 320 --height 240`

**ONNX Runtime errors:**
```bash
# Install specific version
pip install onnxruntime==1.16.0
```

## 📝 Output

The detector will print detections like:
```
[FRAME 42] 2 detection(s) | Total: 15
[FRAME 48] 1 detection(s) | Total: 16
```

Press `Q` in the window or `Ctrl+C` in terminal to stop.

## 🔧 Hardware Requirements

- Raspberry Pi 3 or 4 (recommended: Pi 4 with 4GB RAM)
- USB camera or Pi Camera Module
- Python 3.7+
- 2GB+ free storage

## 📚 Additional Resources

- Model training: YOLOv8
- ONNX format: For CPU optimization
- Frame skipping: Balance accuracy vs. speed

---

For questions or issues, check the main project documentation.
