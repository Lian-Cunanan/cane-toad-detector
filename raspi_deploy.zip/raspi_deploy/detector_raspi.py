#!/usr/bin/env python3
# =============================================================================
# CANE TOAD DETECTOR — Raspberry Pi ONNX Detector
# =============================================================================
#
# ONNX-based detector for Raspberry Pi deployment.
# Uses ONNX Runtime instead of PyTorch for better CPU compatibility.
#
# SETUP:
#   1. Install dependencies:
#         pip install opencv-python numpy onnxruntime
#
#   2. Run:
#         python detector_raspi.py
#
# =============================================================================

import argparse
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np
import onnxruntime as ort


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Cane Toad Detector - Raspberry Pi")
    parser.add_argument(
        "--model", default="best.onnx",
        help="Path to YOLOv8 .onnx model file (default: best.onnx)"
    )
    parser.add_argument(
        "--camera", type=int, default=0,
        help="Camera device index (default: 0)"
    )
    parser.add_argument(
        "--width", type=int, default=640,
        help="Capture width in pixels (default: 640)"
    )
    parser.add_argument(
        "--height", type=int, default=480,
        help="Capture height in pixels (default: 480)"
    )
    parser.add_argument(
        "--conf", type=float, default=0.5,
        help="Minimum confidence threshold (default: 0.5)"
    )
    parser.add_argument(
        "--iou", type=float, default=0.45,
        help="IoU threshold for NMS (default: 0.45)"
    )
    parser.add_argument(
        "--skip", type=int, default=2,
        help="Run inference every N frames (default: 2 for Pi optimization)"
    )
    parser.add_argument(
        "--headless", action="store_true",
        help="Run without display (for headless Pi)"
    )
    return parser.parse_args()


def load_class_names(model_path: str) -> dict:
    """Load class names from class_names.json."""
    model_dir = Path(model_path).parent
    class_file = model_dir / "class_names.json"
    
    if not class_file.exists():
        print(f"[WARN] Class names file not found: {class_file}")
        return {0: "cane_toad"}
    
    try:
        with open(class_file, "r") as f:
            class_names = json.load(f)
            return {int(k): v for k, v in class_names.items()}
    except Exception as e:
        print(f"[WARN] Failed to load class names: {e}")
        return {0: "cane_toad"}


def load_model(model_path: str):
    """Load ONNX model and run warm-up inference."""
    try:
        print(f"[INFO] Loading ONNX model: {model_path}")
        session = ort.InferenceSession(model_path, providers=['CPUExecutionProvider'])
        
        # Get input details
        input_name = session.get_inputs()[0].name
        print(f"[INFO] Model input: {input_name}")
        
        # Warm-up inference
        print("[INFO] Running warm-up inference...")
        dummy = np.random.randn(1, 3, 640, 640).astype(np.float32)
        session.run(None, {input_name: dummy})
        
        print("[INFO] Model loaded successfully!")
        return session, input_name, load_class_names(model_path)
    
    except Exception as e:
        print(f"[ERROR] Failed to load model: {e}")
        sys.exit(1)


def open_camera(camera_index: int, width: int, height: int):
    """Open camera with V4L2 backend for Raspberry Pi."""
    try:
        # Try V4L2 backend first (recommended for Pi)
        cap = cv2.VideoCapture(camera_index, cv2.CAP_V4L2)
        
        if not cap.isOpened():
            # Fallback to default backend
            print("[WARN] V4L2 backend failed, trying default...")
            cap = cv2.VideoCapture(camera_index)
        
        if not cap.isOpened():
            print(f"[ERROR] Could not open camera {camera_index}")
            sys.exit(1)
        
        # Set resolution
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
        cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        
        actual_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        actual_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f"[INFO] Camera opened: {actual_width}x{actual_height}")
        
        return cap
    
    except Exception as e:
        print(f"[ERROR] Camera initialization failed: {e}")
        sys.exit(1)


def letterbox(im, new_shape=(640, 640), color=(114, 114, 114)):
    """Resize and pad image to new_shape with letterboxing."""
    shape = im.shape[:2]  # current shape [height, width]
    
    # Scale ratio (new / old)
    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    
    # Compute padding
    new_unpad = int(round(shape[1] * r)), int(round(shape[0] * r))
    dw, dh = new_shape[1] - new_unpad[0], new_shape[0] - new_unpad[1]
    dw /= 2
    dh /= 2
    
    if shape[::-1] != new_unpad:
        im = cv2.resize(im, new_unpad, interpolation=cv2.INTER_LINEAR)
    top, bottom = int(round(dh - 0.1)), int(round(dh + 0.1))
    left, right = int(round(dw - 0.1)), int(round(dw + 0.1))
    im = cv2.copyMakeBorder(im, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color)
    return im, r, (dw, dh)


def preprocess(image):
    """Preprocess image for YOLO inference."""
    img, ratio, (dw, dh) = letterbox(image, new_shape=(640, 640))
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = img.astype(np.float32) / 255.0
    img = np.transpose(img, (2, 0, 1))
    img = np.expand_dims(img, axis=0)
    return img, ratio, (dw, dh)


def xywh2xyxy(x):
    """Convert bounding box from [x_center, y_center, width, height] to [x1, y1, x2, y2]."""
    y = np.copy(x)
    y[..., 0] = x[..., 0] - x[..., 2] / 2
    y[..., 1] = x[..., 1] - x[..., 3] / 2
    y[..., 2] = x[..., 0] + x[..., 2] / 2
    y[..., 3] = x[..., 1] + x[..., 3] / 2
    return y


def nms(boxes, scores, iou_threshold):
    """Apply Non-Maximum Suppression."""
    x1 = boxes[:, 0]
    y1 = boxes[:, 1]
    x2 = boxes[:, 2]
    y2 = boxes[:, 3]
    
    areas = (x2 - x1) * (y2 - y1)
    order = scores.argsort()[::-1]
    
    keep = []
    while order.size > 0:
        i = order[0]
        keep.append(i)
        
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])
        
        w = np.maximum(0.0, xx2 - xx1)
        h = np.maximum(0.0, yy2 - yy1)
        inter = w * h
        
        iou = inter / (areas[i] + areas[order[1:]] - inter)
        inds = np.where(iou <= iou_threshold)[0]
        order = order[inds + 1]
    
    return keep


def postprocess(outputs, conf_threshold, iou_threshold, ratio, pad):
    """Process YOLO outputs to extract detections."""
    predictions = outputs[0]
    
    if len(predictions.shape) == 3:
        predictions = predictions[0]
    
    # Transpose if needed
    if predictions.shape[0] == 84:
        predictions = predictions.T
    
    # Extract boxes and scores
    boxes = predictions[:, :4]
    scores = predictions[:, 4:].max(axis=1)
    class_ids = predictions[:, 4:].argmax(axis=1)
    
    # Filter by confidence
    mask = scores > conf_threshold
    boxes = boxes[mask]
    scores = scores[mask]
    class_ids = class_ids[mask]
    
    if len(boxes) == 0:
        return [], [], []
    
    # Convert to xyxy format
    boxes = xywh2xyxy(boxes)
    
    # Rescale boxes
    boxes[:, [0, 2]] -= pad[0]
    boxes[:, [1, 3]] -= pad[1]
    boxes /= ratio
    
    # Apply NMS
    indices = nms(boxes, scores, iou_threshold)
    
    return boxes[indices], scores[indices], class_ids[indices]


def draw_detections(frame, boxes, confidences, class_ids, class_names):
    """Draw bounding boxes and labels on frame."""
    for box, conf, cls_id in zip(boxes, confidences, class_ids):
        x1, y1, x2, y2 = map(int, box)
        name = class_names.get(cls_id, 'unknown')
        
        # Draw box
        color = (0, 255, 0)
        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        
        # Draw label
        label = f"{name} {conf:.2f}"
        (w, h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        cv2.rectangle(frame, (x1, y1 - h - 4), (x1 + w, y1), color, -1)
        cv2.putText(frame, label, (x1, y1 - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)


def main() -> None:
    args = parse_args()
    
    print("="*70)
    print("CANE TOAD DETECTOR — Raspberry Pi ONNX Version")
    print("="*70)
    
    # Load model
    session, input_name, class_names = load_model(args.model)
    
    # Open camera
    cap = open_camera(args.camera, args.width, args.height)
    
    if not args.headless:
        WINDOW_NAME = "Cane Toad Detector (Press Q to quit)"
        cv2.namedWindow(WINDOW_NAME, cv2.WINDOW_NORMAL)
    
    frame_index = 0
    last_boxes = []
    last_confidences = []
    last_class_ids = []
    fps_start = time.time()
    fps_counter = 0
    fps_display = 0.0
    total_detections = 0
    
    print(f"\n[INFO] Detection loop started (skip={args.skip}, conf>={args.conf})")
    print("[INFO] Press Ctrl+C to stop.\n")
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("[WARN] Failed to grab frame.")
                break
            
            # Run inference every N frames for performance
            if frame_index % args.skip == 0:
                input_tensor, ratio, pad = preprocess(frame)
                outputs = session.run(None, {input_name: input_tensor})
                boxes, confidences, class_ids = postprocess(
                    outputs, args.conf, args.iou, ratio, pad
                )
                
                last_boxes = boxes
                last_confidences = confidences
                last_class_ids = class_ids
                
                # Log detections
                if len(boxes) > 0:
                    total_detections += len(boxes)
                    print(f"[FRAME {frame_index}] {len(boxes)} detection(s) | Total: {total_detections}")
            
            # Draw detections
            if not args.headless:
                annotated = frame.copy()
                if len(last_boxes) > 0:
                    draw_detections(annotated, last_boxes, last_confidences, last_class_ids, class_names)
                
                # FPS counter
                fps_counter += 1
                elapsed = time.time() - fps_start
                if elapsed >= 1.0:
                    fps_display = fps_counter / elapsed
                    fps_counter = 0
                    fps_start = time.time()
                
                cv2.putText(
                    annotated,
                    f"FPS: {fps_display:.1f} | Detections: {total_detections}",
                    (10, 28),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2
                )
                
                cv2.imshow(WINDOW_NAME, annotated)
                
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    print("\n[INFO] 'Q' pressed — exiting.")
                    break
            
            frame_index += 1
    
    except KeyboardInterrupt:
        print("\n[INFO] Keyboard interrupt — exiting.")
    finally:
        cap.release()
        if not args.headless:
            cv2.destroyAllWindows()
        print(f"\n[INFO] Total detections: {total_detections}")
        print("[INFO] Done.")


if __name__ == "__main__":
    main()
